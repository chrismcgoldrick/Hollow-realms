# The Hollow Realms

A browser-based, D&D-style adventure game. Pre-written multiple-choice story, narrative dice rules (own wording, Genesys-style), code-drawn art. Desktop first.

- Hosting plan: Cloudflare Pages + Workers + D1 (cloud saves, password-protected logins).
- No AI API. All story is pre-written.
- Currently one self-contained file: `index.html`.

See `docs/decisions.md` for the choices made so far.
