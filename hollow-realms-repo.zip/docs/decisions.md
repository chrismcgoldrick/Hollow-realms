# Decisions so far

## Game and hosting
- Single self-contained HTML file for now (`index.html`). Will be split into data, missions and screens later.
- Hosting: Cloudflare Pages/Workers/D1. Saves in the cloud, versioned so later updates can upgrade old saves.
- Any code-drawn animation runs at 15 fps.

## Rules (narrative dice, own wording)
- 6 characteristics: Brawn, Agility, Intellect, Cunning, Willpower, Presence.
- Skills have ranks, max 2 at character creation. Dice pool = proficiency + ability + boost dice.
- Species: Human, Elf, Dwarf, Orc (Orc currently uses the old dragonborn art key).
- Careers: Warrior, Scout, Wizard, Healer, Scholar, Socialite.
- One merged Knowledge skill. Free ranks stack but cap at rank 2 at creation.
- Starting skills: species skills, species choice, human two non-career picks, four free career ranks. Purchases are locked until these are done.
- Starting gold: every career rolls a d100 once. Gold is the only currency for now.

## Character creation steps
1. Heritage and Career  2. Training  3. Gear (accept starting gear OR shop; shop uses placeholder items).

## Sessions (planned, not built)
- Main mission = 2 points, side quest = 1, session = 8 points, overshoot carries over, progress bar at the bottom, automatic resets only for now.

## Gameplay screen
- Full-screen image, story box rising from the bottom, choices under it.
- Hero portrait with Wounds and Strain bottom left. Character, Map and Inventory panel slides from the right.
- Crusader Kings-style look: dark slate panels, thin muted-gold borders, plain sans-serif with serif titles.
- Developer jump menu (Dev button) to skip to character creation or the test mission with a test hero.

## Still to do
- Real story/missions, talents system, save/login layer, gear descriptions (from spreadsheet), career descriptions, starting gear for Wizard/Healer/Socialite, tap support for tooltips on touch.
